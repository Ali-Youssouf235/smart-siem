import { useState } from 'react'
import { colors, roleConfig } from '../theme'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell, Line,
} from 'recharts'

const monthlyTrends = [
  { month: 'Jan', alertes: 245, resolues: 220, menaces: 45 },
  { month: 'Fév', alertes: 280, resolues: 265, menaces: 52 },
  { month: 'Mar', alertes: 220, resolues: 200, menaces: 38 },
  { month: 'Avr', alertes: 310, resolues: 290, menaces: 61 },
  { month: 'Mai', alertes: 275, resolues: 260, menaces: 48 },
  { month: 'Juin', alertes: 166, resolues: 155, menaces: 32 },
]

const threatCategories = [
  { name: 'Malware', value: 28, color: colors.critical },
  { name: 'Phishing', value: 35, color: colors.high },
  { name: 'Accès non autorisé', value: 22, color: colors.warning },
  { name: 'DDoS', value: 12, color: colors.primary },
  { name: 'Autres', value: 3, color: colors.textFaint },
]

const topAssets = [
  { asset: 'Serveur-DB-01', alertes: 45 },
  { asset: 'Firewall-Principal', alertes: 38 },
  { asset: 'Poste-WK-Admin', alertes: 32 },
  { asset: 'Serveur-Web-02', alertes: 28 },
  { asset: 'Cloud-Gateway', alertes: 22 },
]

export default function Rapports({ user }) {
  const [period, setPeriod] = useState('mois')
  const role = user?.role || 'lecteur'

  const reports = [
    { id: 1, name: 'Rapport mensuel — Juin 2024', date: '2024-06-20', type: 'PDF', size: '2.4 MB' },
    { id: 2, name: 'Audit de sécurité T2 2024', date: '2024-06-15', type: 'PDF', size: '5.1 MB' },
    { id: 3, name: 'Analyse des menaces', date: '2024-06-10', type: 'PDF', size: '1.8 MB' },
    { id: 4, name: 'Rapport de conformité RGPD', date: '2024-06-05', type: 'PDF', size: '3.2 MB' },
  ]

  const kpis = [
    { label: 'Alertes ce mois', value: '166', change: '-14%', trend: 'down', icon: 'ti-alert-triangle', color: colors.high },
    { label: 'Taux de résolution', value: '93%', change: '+5%', trend: 'up', icon: 'ti-shield-check', color: colors.success },
    { label: 'MTTR moyen', value: '4h 23m', change: '-12%', trend: 'down', icon: 'ti-trending-up', color: colors.primary },
    { label: 'Score de sécurité', value: '78/100', change: '+3', trend: 'up', icon: 'ti-chart-bar', color: colors.purple },
  ]

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Rapports</h1>
          <p style={styles.subtitle}>Analyses et statistiques de sécurité</p>
        </div>
        <div style={styles.headerActions}>
          <select value={period} onChange={(e) => setPeriod(e.target.value)} style={styles.select}>
            <option value="semaine">Cette semaine</option>
            <option value="mois">Ce mois</option>
            <option value="trimestre">Ce trimestre</option>
            <option value="annee">Cette année</option>
          </select>
          {roleConfig[role]?.canExport && (
            <button style={styles.generateBtn}>
              <i className="ti ti-file-plus" style={{ fontSize: 15 }} />
              Générer rapport
            </button>
          )}
        </div>
      </div>

      <div className="grid-4" style={styles.kpiGrid}>
        {kpis.map((kpi, i) => (
          <div key={i} style={styles.kpiCard}>
            <div style={{ ...styles.kpiIcon, background: `${kpi.color}15` }}>
              <i className={`ti ${kpi.icon}`} style={{ fontSize: 19, color: kpi.color }} />
            </div>
            <div style={styles.kpiContent}>
              <span style={styles.kpiLabel}>{kpi.label}</span>
              <div style={styles.kpiValueRow}>
                <span style={styles.kpiValue}>{kpi.value}</span>
                <span style={{
                  ...styles.kpiChange,
                  color: kpi.trend === 'up' ? colors.success : colors.critical,
                  background: kpi.trend === 'up' ? colors.successBg : colors.criticalBg,
                }}>
                  <i className={`ti ${kpi.trend === 'up' ? 'ti-trending-up' : 'ti-trending-down'}`} style={{ fontSize: 11 }} />
                  {kpi.change}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2" style={styles.chartsRow}>
        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Évolution mensuelle</h3>
              <p style={styles.chartSub}>Alertes, résolues et menaces</p>
            </div>
            <div style={styles.legendRow}>
              <span style={styles.legendItem}><span style={{ ...styles.legendDot, background: colors.primary }} />Alertes</span>
              <span style={styles.legendItem}><span style={{ ...styles.legendDot, background: colors.success }} />Résolues</span>
              <span style={styles.legendItem}><span style={{ ...styles.legendDot, background: colors.critical }} />Menaces</span>
            </div>
          </div>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={monthlyTrends}>
                <defs>
                  <linearGradient id="colorAlertes" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={colors.primary} stopOpacity={0.25} />
                    <stop offset="95%" stopColor={colors.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.borderLight} />
                <XAxis dataKey="month" stroke={colors.textFaint} fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke={colors.textFaint} fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="alertes" stroke={colors.primary} fill="url(#colorAlertes)" strokeWidth={2} />
                <Line type="monotone" dataKey="resolues" stroke={colors.success} strokeWidth={2} dot={false} />
                <Line type="monotone" dataKey="menaces" stroke={colors.critical} strokeWidth={2} dot={false} />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Catégories de menaces</h3>
              <p style={styles.chartSub}>Distribution par type</p>
            </div>
          </div>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={threatCategories} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
                  {threatCategories.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={styles.pieLegend}>
            {threatCategories.map((item, i) => (
              <div key={i} style={styles.pieLegendItem}>
                <div style={{ ...styles.legendColor, background: item.color }} />
                <span style={styles.legendName}>{item.name}</span>
                <span style={styles.legendValue}>{item.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid-2" style={styles.bottomRow}>
        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Actifs les plus exposés</h3>
              <p style={styles.chartSub}>Top 5 par nombre d'alertes</p>
            </div>
          </div>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={topAssets} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke={colors.borderLight} horizontal={false} />
                <XAxis type="number" stroke={colors.textFaint} fontSize={11} tickLine={false} axisLine={false} />
                <YAxis dataKey="asset" type="category" stroke={colors.textFaint} fontSize={10} width={110} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: colors.neutralBg }} />
                <Bar dataKey="alertes" fill={colors.primary} radius={[0, 4, 4, 0]} barSize={16} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Rapports récents</h3>
              <p style={styles.chartSub}>Documents disponibles</p>
            </div>
            {roleConfig[role]?.canExport && (
              <button style={styles.viewAllBtn}>Voir tout <i className="ti ti-arrow-right" style={{ fontSize: 13 }} /></button>
            )}
          </div>
          <div style={styles.reportList}>
            {reports.map((report) => (
              <div key={report.id} style={styles.reportItem}>
                <div style={styles.reportIcon}>
                  <i className="ti ti-file-text" style={{ fontSize: 19, color: colors.primary }} />
                </div>
                <div style={styles.reportContent}>
                  <span style={styles.reportName}>{report.name}</span>
                  <div style={styles.reportMeta}>
                    <span style={styles.reportDate}>
                      <i className="ti ti-calendar" style={{ fontSize: 11 }} />
                      {report.date}
                    </span>
                    <span style={styles.reportSize}>{report.size}</span>
                  </div>
                </div>
                {roleConfig[role]?.canExport ? (
                  <button style={styles.downloadBtn}>
                    <i className="ti ti-download" style={{ fontSize: 16 }} />
                  </button>
                ) : (
                  <button style={styles.downloadBtn} title="Lecteur : export non autorisé" disabled>
                    <i className="ti ti-eye" style={{ fontSize: 16 }} />
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

const tooltipStyle = { backgroundColor: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 12 }

const styles = {
  container: { display: 'flex', flexDirection: 'column', gap: 20 },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 14 },
  title: { fontSize: 24, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  subtitle: { fontSize: 13, color: colors.textMuted, marginTop: 3 },
  headerActions: { display: 'flex', gap: 10, alignItems: 'center' },
  select: {
    padding: '9px 30px 9px 12px', border: `1px solid ${colors.neutralBorder}`, borderRadius: 8,
    fontSize: 13, background: '#fff', cursor: 'pointer', appearance: 'none',
    backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2212%22%20height%3D%2212%22%3E%3Cpath%20fill%3D%22%2364748b%22%20d%3D%22M6%208L1%203h10z%22/%3E%3C/svg%3E")',
    backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center',
  },
  generateBtn: {
    display: 'flex', alignItems: 'center', gap: 7, padding: '9px 14px',
    background: colors.primary, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff',
  },
  kpiGrid: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 },
  kpiCard: { background: '#fff', borderRadius: 12, padding: 18, display: 'flex', gap: 14, alignItems: 'center', border: `1px solid ${colors.border}` },
  kpiIcon: { width: 42, height: 42, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  kpiContent: { display: 'flex', flexDirection: 'column', gap: 4 },
  kpiLabel: { fontSize: 12, color: colors.textMuted, fontWeight: 500 },
  kpiValueRow: { display: 'flex', alignItems: 'center', gap: 8 },
  kpiValue: { fontSize: 22, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  kpiChange: { display: 'flex', alignItems: 'center', gap: 2, fontSize: 11, fontWeight: 600, borderRadius: 6, padding: '2px 6px' },
  chartsRow: { display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14 },
  chartCard: { background: '#fff', borderRadius: 12, padding: 18, border: `1px solid ${colors.border}` },
  chartHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 14, flexWrap: 'wrap', gap: 8 },
  chartTitle: { fontSize: 15, fontWeight: 700, color: colors.text },
  chartSub: { fontSize: 12, color: colors.textFaint, marginTop: 2 },
  legendRow: { display: 'flex', gap: 14, flexWrap: 'wrap' },
  legendItem: { display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: colors.textMuted, fontWeight: 500 },
  legendDot: { width: 8, height: 8, borderRadius: 2 },
  chartContainer: { width: '100%' },
  pieLegend: { display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginTop: 12 },
  pieLegendItem: { display: 'flex', alignItems: 'center', gap: 8 },
  legendColor: { width: 10, height: 10, borderRadius: 3 },
  legendName: { fontSize: 12, color: colors.textMuted, flex: 1 },
  legendValue: { fontSize: 12, fontWeight: 700, color: colors.text },
  bottomRow: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 14 },
  viewAllBtn: { display: 'flex', alignItems: 'center', gap: 4, background: 'none', border: 'none', color: colors.primary, fontSize: 12, fontWeight: 600 },
  reportList: { display: 'flex', flexDirection: 'column', gap: 10 },
  reportItem: { display: 'flex', alignItems: 'center', gap: 12, padding: '11px 12px', background: colors.neutralBg, borderRadius: 8, border: `1px solid ${colors.borderLight}` },
  reportIcon: { width: 38, height: 38, borderRadius: 8, background: colors.primaryBg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  reportContent: { flex: 1, display: 'flex', flexDirection: 'column', gap: 3, minWidth: 0 },
  reportName: { fontSize: 13, fontWeight: 600, color: colors.text, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' },
  reportMeta: { display: 'flex', gap: 12, fontSize: 11, color: colors.textFaint },
  reportDate: { display: 'flex', alignItems: 'center', gap: 4 },
  reportSize: {},
  downloadBtn: { background: 'transparent', border: 'none', padding: 8, borderRadius: 6, color: colors.textMuted, display: 'flex', alignItems: 'center', justifyContent: 'center' },
}
