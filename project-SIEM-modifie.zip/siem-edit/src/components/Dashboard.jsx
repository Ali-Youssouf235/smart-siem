import { colors, severityConfig } from '../theme'
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  BarChart, Bar, PieChart, Pie, Cell,
} from 'recharts'

const alertsData = [
  { time: '00:00', alerts: 12, resolved: 10 },
  { time: '04:00', alerts: 8, resolved: 7 },
  { time: '08:00', alerts: 25, resolved: 20 },
  { time: '12:00', alerts: 42, resolved: 38 },
  { time: '16:00', alerts: 35, resolved: 32 },
  { time: '20:00', alerts: 18, resolved: 15 },
  { time: '24:00', alerts: 14, resolved: 12 },
]

const severityData = [
  { name: 'Critique', value: 8, color: colors.critical },
  { name: 'Haute', value: 24, color: colors.high },
  { name: 'Moyenne', value: 45, color: colors.warning },
  { name: 'Basse', value: 89, color: colors.success },
]

const sourceData = [
  { name: 'Firewall', count: 156 },
  { name: 'Endpoints', count: 98 },
  { name: 'Applications', count: 67 },
  { name: 'Réseau', count: 45 },
  { name: 'Cloud', count: 34 },
]

const recentAlerts = [
  { message: 'Tentative d\'accès non autorisé au serveur principal', time: 'Il y a 2 min', severity: 'critical', source: 'Firewall' },
  { message: 'Connexion suspecte depuis un pays étranger', time: 'Il y a 8 min', severity: 'high', source: 'Auth System' },
  { message: 'Échec d\'authentification multiple — admin', time: 'Il y a 15 min', severity: 'high', source: 'LDAP' },
  { message: 'Scan de ports détecté sur le réseau interne', time: 'Il y a 22 min', severity: 'warning', source: 'IDS' },
  { message: 'Trafic sortant inhabituel détecté', time: 'Il y a 30 min', severity: 'high', source: 'Network Monitor' },
]

const uebaUsers = [
  { name: 'Lucas Petit', score: 92, status: 'critique', dept: 'IT' },
  { name: 'Jean Dupont', score: 85, status: 'risque', dept: 'IT' },
  { name: 'Pierre Durand', score: 72, status: 'attention', dept: 'Finance' },
  { name: 'Marie Martin', score: 45, status: 'normal', dept: 'RH' },
]

export default function Dashboard({ user, onNavigate }) {
  const stats = [
    { label: 'Alertes actives', value: '166', change: '+12%', trend: 'up', icon: 'ti-alert-triangle', color: colors.high, bg: colors.highBg },
    { label: 'Menaces bloquées', value: '1,247', change: '+23%', trend: 'up', icon: 'ti-shield-check', color: colors.success, bg: colors.successBg },
    { label: 'Événements/s', value: '2.4k', change: '-5%', trend: 'down', icon: 'ti-activity', color: colors.primary, bg: colors.primaryBg },
    { label: 'Uptime système', value: '99.8%', change: '+0.2%', trend: 'up', icon: 'ti-server', color: colors.purple, bg: colors.purpleBg },
  ]

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Tableau de bord</h1>
          <p style={styles.subtitle}>Vue d'ensemble de la sécurité · Cellule CTU</p>
        </div>
        <div style={styles.timeBadge}>
          <span className="live-dot" style={styles.dotGreen} />
          <span>Temps réel · Mis à jour il y a 2 min</span>
        </div>
      </div>

      <div className="grid-4" style={styles.statsGrid}>
        {stats.map((stat, i) => (
          <div key={i} style={styles.statCard}>
            <div style={{ ...styles.statIcon, background: stat.bg }}>
              <i className={`ti ${stat.icon}`} style={{ fontSize: 20, color: stat.color }} />
            </div>
            <div style={styles.statContent}>
              <span style={styles.statLabel}>{stat.label}</span>
              <div style={styles.statValueRow}>
                <span className="kpi-val" style={styles.statValue}>{stat.value}</span>
                <span style={{
                  ...styles.statChange,
                  color: stat.trend === 'up' ? colors.success : colors.critical,
                  background: stat.trend === 'up' ? colors.successBg : colors.criticalBg,
                }}>
                  <i className={`ti ${stat.trend === 'up' ? 'ti-trending-up' : 'ti-trending-down'}`} style={{ fontSize: 12 }} />
                  {stat.change}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid-2" style={styles.chartsGrid}>
        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Activité des alertes (24h)</h3>
              <p style={styles.chartSub}>Alertes détectées vs résolues</p>
            </div>
            <div style={styles.legendRow}>
              <span style={styles.legendItem}><span style={{ ...styles.legendDot, background: colors.primary }} />Alertes</span>
              <span style={styles.legendItem}><span style={{ ...styles.legendDot, background: colors.success }} />Résolues</span>
            </div>
          </div>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={alertsData}>
                <defs>
                  <linearGradient id="alertGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={colors.primary} stopOpacity={0.25} />
                    <stop offset="95%" stopColor={colors.primary} stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke={colors.borderLight} />
                <XAxis dataKey="time" stroke={colors.textFaint} fontSize={11} tickLine={false} axisLine={false} />
                <YAxis stroke={colors.textFaint} fontSize={11} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={tooltipStyle} />
                <Area type="monotone" dataKey="alerts" stroke={colors.primary} strokeWidth={2} fill="url(#alertGradient)" />
                <Area type="monotone" dataKey="resolved" stroke={colors.success} strokeWidth={2} fill="none" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Répartition par sévérité</h3>
              <p style={styles.chartSub}>Distribution des alertes actives</p>
            </div>
          </div>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={severityData} cx="50%" cy="50%" innerRadius={55} outerRadius={90} paddingAngle={3} dataKey="value">
                  {severityData.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                </Pie>
                <Tooltip contentStyle={tooltipStyle} />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div style={styles.legendGrid}>
            {severityData.map((item, i) => (
              <div key={i} style={styles.legendItemRow}>
                <div style={{ ...styles.legendColor, background: item.color }} />
                <span style={styles.legendLabel}>{item.name}</span>
                <span style={styles.legendValue}>{item.value}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="grid-2" style={styles.bottomGrid}>
        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Sources d'alertes</h3>
              <p style={styles.chartSub}>Top 5 des capteurs</p>
            </div>
          </div>
          <div style={styles.chartContainer}>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={sourceData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke={colors.borderLight} horizontal={false} />
                <XAxis type="number" stroke={colors.textFaint} fontSize={11} tickLine={false} axisLine={false} />
                <YAxis dataKey="name" type="category" stroke={colors.textFaint} fontSize={11} width={80} tickLine={false} axisLine={false} />
                <Tooltip contentStyle={tooltipStyle} cursor={{ fill: colors.neutralBg }} />
                <Bar dataKey="count" fill={colors.primary} radius={[0, 4, 4, 0]} barSize={18} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Alertes récentes</h3>
              <p style={styles.chartSub}>Dernières 24 heures</p>
            </div>
            <button style={styles.viewAllBtn} onClick={() => onNavigate('alertes')}>
              Voir tout <i className="ti ti-arrow-right" style={{ fontSize: 13 }} />
            </button>
          </div>
          <div style={styles.alertList}>
            {recentAlerts.map((alert, i) => {
              const sev = severityConfig[alert.severity]
              return (
                <div key={i} style={styles.alertItem}>
                  <div style={{ ...styles.severityDot, background: sev.color }} />
                  <div style={styles.alertContent}>
                    <span style={styles.alertText}>{alert.message}</span>
                    <span style={styles.alertMeta}>
                      <i className="ti ti-source" style={{ fontSize: 11 }} />
                      {alert.source} · {alert.time}
                    </span>
                  </div>
                  <span style={{ ...styles.alertBadge, background: sev.bg, color: sev.color }}>
                    {sev.label}
                  </span>
                </div>
              )
            })}
          </div>
        </div>
      </div>

      <div className="grid-2" style={styles.bottomGrid}>
        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>UEBA — Comportements à risque</h3>
              <p style={styles.chartSub}>Utilisateurs surveillés</p>
            </div>
            <button style={styles.viewAllBtn} onClick={() => onNavigate('ueba')}>
              Voir tout <i className="ti ti-arrow-right" style={{ fontSize: 13 }} />
            </button>
          </div>
          <div style={styles.uebaList}>
            {uebaUsers.map((u, i) => {
              const sev = u.status === 'critique' ? severityConfig.critical : u.status === 'risque' ? severityConfig.high : u.status === 'attention' ? severityConfig.warning : severityConfig.info
              return (
                <div key={i} style={styles.uebaItem}>
                  <div style={{ ...styles.uebaAvatar, background: sev.bg, color: sev.color }}>
                    {u.name.charAt(0)}
                  </div>
                  <div style={styles.uebaInfo}>
                    <span style={styles.uebaName}>{u.name}</span>
                    <span style={styles.uebaDept}>{u.dept}</span>
                  </div>
                  <div style={styles.uebaScore}>
                    <div style={{ ...styles.uebaScoreBar, background: sev.color, width: `${u.score}%` }} />
                  </div>
                  <span style={{ ...styles.uebaScoreVal, color: sev.color }}>{u.score}</span>
                </div>
              )
            })}
          </div>
        </div>

        <div style={styles.chartCard}>
          <div style={styles.chartHeader}>
            <div>
              <h3 style={styles.chartTitle}>Flux d'événements (logs/s)</h3>
              <p style={styles.chartSub}>Volume en temps réel</p>
            </div>
          </div>
          <div style={styles.logStream}>
            {[
              { time: '14:32:15', src: 'FW-01', msg: 'DENY TCP 192.168.1.45:443 → 10.0.0.1', sev: 'high' },
              { time: '14:32:12', src: 'IDS', msg: 'PORT_SCAN detected from 172.16.0.100', sev: 'warning' },
              { time: '14:32:08', src: 'AUTH', msg: 'LOGIN_SUCCESS user=admin from 10.0.0.15', sev: 'info' },
              { time: '14:32:03', src: 'EDR', msg: 'PROCESS_INJECT pid=4421 on WK-15', sev: 'critical' },
              { time: '14:31:58', src: 'NET', msg: 'DNS query: c2-malicious.example.com', sev: 'high' },
              { time: '14:31:50', src: 'DLP', msg: 'FILE_ACCESS /confidentiel/rapport_q2.pdf', sev: 'warning' },
            ].map((log, i) => {
              const sev = severityConfig[log.sev]
              return (
                <div key={i} style={styles.logLine}>
                  <span className="mono" style={styles.logTime}>{log.time}</span>
                  <span style={{ ...styles.logSrc, background: sev.bg, color: sev.color }}>{log.src}</span>
                  <span className="mono" style={styles.logMsg}>{log.msg}</span>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    </div>
  )
}

const tooltipStyle = {
  backgroundColor: '#fff',
  border: `1px solid ${colors.border}`,
  borderRadius: 8,
  fontSize: 12,
  boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
}

const styles = {
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: 20,
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    flexWrap: 'wrap',
    gap: 12,
  },
  title: {
    fontSize: 24,
    fontWeight: 700,
    color: colors.text,
    letterSpacing: '-0.5px',
  },
  subtitle: {
    fontSize: 13,
    color: colors.textMuted,
    marginTop: 3,
  },
  timeBadge: {
    display: 'flex',
    alignItems: 'center',
    gap: 6,
    padding: '7px 12px',
    background: '#fff',
    border: `1px solid ${colors.border}`,
    borderRadius: 20,
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: 500,
  },
  dotGreen: {
    width: 7,
    height: 7,
    background: '#4CAF50',
    borderRadius: '50%',
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: 14,
  },
  statCard: {
    background: '#fff',
    borderRadius: 12,
    padding: 18,
    display: 'flex',
    gap: 14,
    alignItems: 'center',
    border: `1px solid ${colors.border}`,
  },
  statIcon: {
    width: 44,
    height: 44,
    borderRadius: 10,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexShrink: 0,
  },
  statContent: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
  },
  statLabel: {
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: 500,
  },
  statValueRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  },
  statValue: {
    fontSize: 26,
    fontWeight: 700,
    color: colors.text,
    letterSpacing: '-0.5px',
  },
  statChange: {
    display: 'flex',
    alignItems: 'center',
    gap: 2,
    fontSize: 11,
    fontWeight: 600,
    borderRadius: 6,
    padding: '2px 6px',
  },
  chartsGrid: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: 14,
  },
  chartCard: {
    background: '#fff',
    borderRadius: 12,
    padding: 18,
    border: `1px solid ${colors.border}`,
  },
  chartHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 14,
    flexWrap: 'wrap',
    gap: 8,
  },
  chartTitle: {
    fontSize: 15,
    fontWeight: 700,
    color: colors.text,
  },
  chartSub: {
    fontSize: 12,
    color: colors.textFaint,
    marginTop: 2,
  },
  legendRow: {
    display: 'flex',
    gap: 14,
  },
  legendItem: {
    display: 'flex',
    alignItems: 'center',
    gap: 5,
    fontSize: 12,
    color: colors.textMuted,
    fontWeight: 500,
  },
  legendDot: {
    width: 8,
    height: 8,
    borderRadius: 2,
  },
  chartContainer: {
    width: '100%',
  },
  legendGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: 8,
    marginTop: 12,
  },
  legendItemRow: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
  },
  legendColor: {
    width: 10,
    height: 10,
    borderRadius: 3,
  },
  legendLabel: {
    fontSize: 12,
    color: colors.textMuted,
    flex: 1,
  },
  legendValue: {
    fontSize: 12,
    fontWeight: 700,
    color: colors.text,
  },
  bottomGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 14,
  },
  viewAllBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: 4,
    background: 'none',
    border: 'none',
    color: colors.primary,
    fontSize: 12,
    fontWeight: 600,
  },
  alertList: {
    display: 'flex',
    flexDirection: 'column',
    gap: 8,
  },
  alertItem: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    padding: '10px 12px',
    background: colors.neutralBg,
    borderRadius: 8,
    border: `1px solid ${colors.borderLight}`,
  },
  severityDot: {
    width: 8,
    height: 8,
    borderRadius: '50%',
    flexShrink: 0,
  },
  alertContent: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: 2,
    minWidth: 0,
  },
  alertText: {
    fontSize: 13,
    color: colors.text,
    fontWeight: 500,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
  alertMeta: {
    fontSize: 11,
    color: colors.textFaint,
    display: 'flex',
    alignItems: 'center',
    gap: 4,
  },
  alertBadge: {
    padding: '3px 8px',
    borderRadius: 5,
    fontSize: 10,
    fontWeight: 700,
    whiteSpace: 'nowrap',
    letterSpacing: '0.03em',
  },
  uebaList: {
    display: 'flex',
    flexDirection: 'column',
    gap: 10,
  },
  uebaItem: {
    display: 'flex',
    alignItems: 'center',
    gap: 10,
  },
  uebaAvatar: {
    width: 32,
    height: 32,
    borderRadius: '50%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 13,
    fontWeight: 700,
    flexShrink: 0,
  },
  uebaInfo: {
    display: 'flex',
    flexDirection: 'column',
    minWidth: 100,
  },
  uebaName: {
    fontSize: 13,
    fontWeight: 600,
    color: colors.text,
  },
  uebaDept: {
    fontSize: 11,
    color: colors.textFaint,
  },
  uebaScore: {
    flex: 1,
    height: 6,
    background: colors.neutralBg,
    borderRadius: 3,
    overflow: 'hidden',
    margin: '0 8px',
  },
  uebaScoreBar: {
    height: '100%',
    borderRadius: 3,
  },
  uebaScoreVal: {
    fontSize: 13,
    fontWeight: 700,
    width: 28,
    textAlign: 'right',
  },
  logStream: {
    display: 'flex',
    flexDirection: 'column',
    gap: 4,
    fontFamily: 'JetBrains Mono, monospace',
    maxHeight: 240,
    overflowY: 'auto',
  },
  logLine: {
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    padding: '5px 8px',
    borderRadius: 6,
    background: colors.neutralBg,
    fontSize: 11,
  },
  logTime: {
    color: colors.textFaint,
    fontSize: 11,
    flexShrink: 0,
  },
  logSrc: {
    fontSize: 9,
    fontWeight: 700,
    padding: '2px 6px',
    borderRadius: 4,
    flexShrink: 0,
    letterSpacing: '0.03em',
  },
  logMsg: {
    color: colors.textBody,
    fontSize: 11,
    whiteSpace: 'nowrap',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
  },
}
