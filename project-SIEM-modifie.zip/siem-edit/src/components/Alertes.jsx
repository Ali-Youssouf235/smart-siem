import { useState } from 'react'
import { colors, severityConfig, roleConfig } from '../theme'

const mockAlerts = [
  { id: 'ALR-001', message: 'Tentative d\'accès non autorisé au serveur principal', source: 'Firewall', severity: 'critical', status: 'nouveau', time: '2024-06-24 14:32', ip: '192.168.1.45', host: 'SRV-DB-01', mitre: 'T1110 - Brute Force' },
  { id: 'ALR-002', message: 'Connexion suspecte depuis un pays étranger', source: 'Auth System', severity: 'high', status: 'en_cours', time: '2024-06-24 14:28', ip: '203.45.67.89', host: 'GW-VPN-01', mitre: 'T1078 - Valid Accounts' },
  { id: 'ALR-003', message: 'Échec d\'authentification multiple pour admin', source: 'LDAP', severity: 'high', status: 'nouveau', time: '2024-06-24 14:15', ip: '10.0.0.15', host: 'DC-01', mitre: 'T1110 - Brute Force' },
  { id: 'ALR-004', message: 'Scan de ports détecté sur le réseau interne', source: 'IDS', severity: 'warning', status: 'resolu', time: '2024-06-24 13:55', ip: '172.16.0.100', host: 'SW-CORE', mitre: 'T1046 - Network Service Discovery' },
  { id: 'ALR-005', message: 'Mise à jour de sécurité manquante sur serveur-03', source: 'Vuln Scanner', severity: 'warning', status: 'ignore', time: '2024-06-24 13:42', ip: '192.168.1.12', host: 'SRV-03', mitre: 'N/A' },
  { id: 'ALR-006', message: 'Trafic sortant inhabituel détecté', source: 'Network Monitor', severity: 'high', status: 'nouveau', time: '2024-06-24 13:30', ip: '192.168.1.78', host: 'WK-15', mitre: 'T1041 - Exfiltration Over C2' },
  { id: 'ALR-007', message: 'Tentative d\'escalade de privilèges', source: 'Endpoint', severity: 'critical', status: 'en_cours', time: '2024-06-24 13:15', ip: '10.0.0.55', host: 'WK-ADMIN', mitre: 'T1068 - Exploitation for Privilege Escalation' },
  { id: 'ALR-008', message: 'Accès fichier sensible détecté', source: 'DLP', severity: 'warning', status: 'nouveau', time: '2024-06-24 12:58', ip: '192.168.1.200', host: 'SRV-FILE', mitre: 'T1083 - File and Directory Discovery' },
  { id: 'ALR-009', message: 'Malware potentiel détecté sur poste-wk-15', source: 'Antivirus', severity: 'high', status: 'resolu', time: '2024-06-24 12:30', ip: '192.168.1.95', host: 'WK-15', mitre: 'T1204 - User Execution' },
  { id: 'ALR-010', message: 'Configuration pare-feu modifiée sans autorisation', source: 'Firewall', severity: 'critical', status: 'nouveau', time: '2024-06-24 12:15', ip: '192.168.1.1', host: 'FW-01', mitre: 'T1562 - Impair Defenses' },
]

const statusConfig = {
  nouveau: { label: 'Nouveau', color: colors.primary, bg: colors.primaryBg, icon: 'ti-point-filled' },
  en_cours: { label: 'En cours', color: colors.high, bg: colors.highBg, icon: 'ti-loader' },
  resolu: { label: 'Résolu', color: colors.success, bg: colors.successBg, icon: 'ti-circle-check' },
  ignore: { label: 'Ignoré', color: colors.textFaint, bg: colors.neutralBg, icon: 'ti-circle-x' },
}

export default function Alertes({ user }) {
  const [searchTerm, setSearchTerm] = useState('')
  const [severityFilter, setSeverityFilter] = useState('tous')
  const [statusFilter, setStatusFilter] = useState('tous')
  const [sortOrder, setSortOrder] = useState('desc')
  const [expandedRow, setExpandedRow] = useState(null)

  const role = user?.role || 'lecteur'
  const canAct = roleConfig[role]?.canAcknowledge || false

  const filteredAlerts = mockAlerts
    .filter(alert => {
      const matchesSearch = alert.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.source.toLowerCase().includes(searchTerm.toLowerCase()) ||
        alert.ip.includes(searchTerm) ||
        alert.id.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesSeverity = severityFilter === 'tous' || alert.severity === severityFilter
      const matchesStatus = statusFilter === 'tous' || alert.status === statusFilter
      return matchesSearch && matchesSeverity && matchesStatus
    })
    .sort((a, b) => sortOrder === 'desc' ? new Date(b.time) - new Date(a.time) : new Date(a.time) - new Date(b.time))

  const stats = {
    total: mockAlerts.length,
    nouveau: mockAlerts.filter(a => a.status === 'nouveau').length,
    en_cours: mockAlerts.filter(a => a.status === 'en_cours').length,
    resolu: mockAlerts.filter(a => a.status === 'resolu').length,
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Gestion des alertes</h1>
          <p style={styles.subtitle}>Surveillez et gérez les alertes de sécurité</p>
        </div>
        <div style={styles.actions}>
          <button style={styles.refreshBtn}>
            <i className="ti ti-refresh" style={{ fontSize: 15 }} />
            Actualiser
          </button>
          {roleConfig[role]?.canExport && (
            <button style={styles.exportBtn}>
              <i className="ti ti-download" style={{ fontSize: 15 }} />
              Exporter
            </button>
          )}
        </div>
      </div>

      <div style={styles.statsRow}>
        <div style={{ ...styles.statBadge, background: colors.primaryBg, borderColor: colors.primaryBorder }}>
          <i className="ti ti-alert-triangle" style={{ fontSize: 14, color: colors.primary }} />
          <span style={{ color: colors.primary, fontWeight: 600 }}>Total: {stats.total}</span>
        </div>
        <div style={{ ...styles.statBadge, background: colors.primaryBg, borderColor: colors.primaryBorder }}>
          <i className="ti ti-point-filled" style={{ fontSize: 14, color: colors.primary }} />
          <span style={{ color: colors.primary, fontWeight: 600 }}>Nouveaux: {stats.nouveau}</span>
        </div>
        <div style={{ ...styles.statBadge, background: colors.highBg, borderColor: colors.highBorder }}>
          <i className="ti ti-loader" style={{ fontSize: 14, color: colors.high }} />
          <span style={{ color: colors.high, fontWeight: 600 }}>En cours: {stats.en_cours}</span>
        </div>
        <div style={{ ...styles.statBadge, background: colors.successBg, borderColor: colors.successBorder }}>
          <i className="ti ti-circle-check" style={{ fontSize: 14, color: colors.success }} />
          <span style={{ color: colors.success, fontWeight: 600 }}>Résolus: {stats.resolu}</span>
        </div>
      </div>

      <div style={styles.filtersCard}>
        <div style={styles.searchWrapper}>
          <i className="ti ti-search" style={styles.searchIcon} />
          <input
            type="text"
            placeholder="Rechercher par message, source, IP ou ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            style={styles.searchInput}
          />
        </div>

        <div style={styles.filterGroup}>
          <div style={styles.filterItem}>
            <i className="ti ti-filter" style={{ fontSize: 13, color: colors.textFaint }} />
            <select value={severityFilter} onChange={(e) => setSeverityFilter(e.target.value)} style={styles.select}>
              <option value="tous">Toutes sévérités</option>
              <option value="critical">Critique</option>
              <option value="high">Haute</option>
              <option value="warning">Moyenne</option>
              <option value="info">Basse</option>
            </select>
          </div>

          <div style={styles.filterItem}>
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={styles.select}>
              <option value="tous">Tous statuts</option>
              <option value="nouveau">Nouveau</option>
              <option value="en_cours">En cours</option>
              <option value="resolu">Résolu</option>
              <option value="ignore">Ignoré</option>
            </select>
          </div>

          <button onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')} style={styles.sortBtn}>
            <i className={`ti ${sortOrder === 'desc' ? 'ti-sort-descending' : 'ti-sort-ascending'}`} style={{ fontSize: 14 }} />
            Date
          </button>
        </div>
      </div>

      <div style={styles.alertTable}>
        <div style={styles.tableHeader}>
          <div style={{ ...styles.tableCell, flex: '0 0 80px' }}>ID</div>
          <div style={{ ...styles.tableCell, flex: 2 }}>Message</div>
          <div style={{ ...styles.tableCell, flex: '0 0 110px' }}>Sévérité</div>
          <div style={{ ...styles.tableCell, flex: '0 0 100px' }}>Statut</div>
          <div style={{ ...styles.tableCell, flex: '0 0 130px' }}>Date</div>
          <div style={{ ...styles.tableCell, flex: '0 0 40px' }}></div>
        </div>

        {filteredAlerts.map((alert) => {
          const sev = severityConfig[alert.severity]
          const st = statusConfig[alert.status]
          return (
            <div key={alert.id}>
              <div
                style={{ ...styles.tableRow, ...(expandedRow === alert.id ? styles.tableRowExpanded : {}) }}
                onClick={() => setExpandedRow(expandedRow === alert.id ? null : alert.id)}
              >
                <div style={{ ...styles.tableCell, flex: '0 0 80px' }}>
                  <span className="mono" style={styles.alertId}>{alert.id}</span>
                </div>
                <div style={{ ...styles.tableCell, flex: 2, flexDirection: 'column', alignItems: 'flex-start', gap: 2 }}>
                  <span style={styles.alertMessage}>{alert.message}</span>
                  <span style={styles.alertSource}>
                    <i className="ti ti-source" style={{ fontSize: 10 }} />
                    {alert.source} · {alert.host}
                  </span>
                </div>
                <div style={{ ...styles.tableCell, flex: '0 0 110px' }}>
                  <span style={{ ...styles.severityBadge, background: sev.bg, color: sev.color, border: `1px solid ${sev.border}` }}>
                    {sev.label}
                  </span>
                </div>
                <div style={{ ...styles.tableCell, flex: '0 0 100px' }}>
                  <span style={{ ...styles.statusBadge, background: st.bg, color: st.color }}>
                    <i className={`ti ${st.icon}`} style={{ fontSize: 11 }} />
                    {st.label}
                  </span>
                </div>
                <div style={{ ...styles.tableCell, flex: '0 0 130px', color: colors.textFaint, fontSize: 12 }}>
                  <i className="ti ti-clock" style={{ fontSize: 12, marginRight: 4 }} />
                  {new Date(alert.time).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}
                </div>
                <div style={{ ...styles.tableCell, flex: '0 0 40px', justifyContent: 'center' }}>
                  <i className={`ti ${expandedRow === alert.id ? 'ti-chevron-up' : 'ti-chevron-down'}`} style={{ fontSize: 16, color: colors.textFaint }} />
                </div>
              </div>

              {expandedRow === alert.id && (
                <div style={styles.expandedRow}>
                  <div style={styles.expandedGrid}>
                    <div style={styles.expandedItem}>
                      <span style={styles.expandedLabel}>Adresse IP</span>
                      <span className="mono" style={styles.expandedValue}>{alert.ip}</span>
                    </div>
                    <div style={styles.expandedItem}>
                      <span style={styles.expandedLabel}>Hôte</span>
                      <span style={styles.expandedValue}>{alert.host}</span>
                    </div>
                    <div style={styles.expandedItem}>
                      <span style={styles.expandedLabel}>Source</span>
                      <span style={styles.expandedValue}>{alert.source}</span>
                    </div>
                    <div style={styles.expandedItem}>
                      <span style={styles.expandedLabel}>Date complète</span>
                      <span style={styles.expandedValue}>{alert.time}</span>
                    </div>
                    <div style={styles.expandedItem}>
                      <span style={styles.expandedLabel}>MITRE ATT&CK</span>
                      <span className="mono" style={{ ...styles.expandedValue, color: colors.purple }}>{alert.mitre}</span>
                    </div>
                  </div>

                  {canAct ? (
                    <div style={styles.actionButtons}>
                      <button style={styles.actionBtnPrimary}>
                        <i className="ti ti-circle-check" style={{ fontSize: 15 }} />
                        Marquer résolu
                      </button>
                      <button style={styles.actionBtnInvestigate}>
                        <i className="ti ti-search" style={{ fontSize: 15 }} />
                        Investiguer
                      </button>
                      <button style={styles.actionBtnIgnore}>
                        <i className="ti ti-circle-x" style={{ fontSize: 15 }} />
                        Ignorer
                      </button>
                    </div>
                  ) : (
                    <div style={styles.readOnlyNotice}>
                      <i className="ti ti-info-circle" style={{ fontSize: 14 }} />
                      Profil Lecteur : consultation uniquement. Les actions sur les alertes nécessitent un profil Analyste ou Admin.
                    </div>
                  )}
                </div>
              )}
            </div>
          )
        })}
      </div>

      {filteredAlerts.length === 0 && (
        <div style={styles.emptyState}>
          <i className="ti ti-search" style={{ fontSize: 40, color: colors.textLight }} />
          <p style={styles.emptyText}>Aucune alerte ne correspond à vos critères</p>
        </div>
      )}
    </div>
  )
}

const styles = {
  container: { display: 'flex', flexDirection: 'column', gap: 18 },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 14 },
  title: { fontSize: 24, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  subtitle: { fontSize: 13, color: colors.textMuted, marginTop: 3 },
  actions: { display: 'flex', gap: 10 },
  refreshBtn: {
    display: 'flex', alignItems: 'center', gap: 7, padding: '9px 14px',
    background: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8,
    fontSize: 13, fontWeight: 500, color: colors.textBody,
  },
  exportBtn: {
    display: 'flex', alignItems: 'center', gap: 7, padding: '9px 14px',
    background: colors.primary, border: 'none', borderRadius: 8,
    fontSize: 13, fontWeight: 600, color: '#fff',
  },
  statsRow: { display: 'flex', gap: 10, flexWrap: 'wrap' },
  statBadge: {
    display: 'flex', alignItems: 'center', gap: 6, padding: '7px 14px',
    borderRadius: 8, border: '1px solid', fontSize: 12,
  },
  filtersCard: {
    background: '#fff', borderRadius: 12, padding: 14, border: `1px solid ${colors.border}`,
    display: 'flex', gap: 12, flexWrap: 'wrap', alignItems: 'center',
  },
  searchWrapper: { position: 'relative', flex: 1, minWidth: 250 },
  searchIcon: { position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 16, color: colors.textFaint },
  searchInput: {
    width: '100%', padding: '11px 12px 11px 40px', border: `1px solid ${colors.neutralBorder}`,
    borderRadius: 8, fontSize: 13, background: colors.neutralBg, color: colors.text, outline: 'none',
  },
  filterGroup: { display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' },
  filterItem: { display: 'flex', alignItems: 'center', gap: 6 },
  select: {
    padding: '9px 30px 9px 12px', border: `1px solid ${colors.neutralBorder}`, borderRadius: 8,
    fontSize: 13, background: '#fff', color: colors.textBody, cursor: 'pointer', appearance: 'none',
    backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2212%22%20height%3D%2212%22%3E%3Cpath%20fill%3D%22%2364748b%22%20d%3D%22M6%208L1%203h10z%22/%3E%3C/svg%3E")',
    backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center',
  },
  sortBtn: {
    display: 'flex', alignItems: 'center', gap: 5, padding: '9px 12px',
    border: `1px solid ${colors.neutralBorder}`, borderRadius: 8, fontSize: 13,
    background: '#fff', color: colors.textBody,
  },
  alertTable: { background: '#fff', borderRadius: 12, border: `1px solid ${colors.border}`, overflow: 'hidden' },
  tableHeader: {
    display: 'flex', padding: '12px 16px', background: colors.neutralBg,
    borderBottom: `1px solid ${colors.border}`, fontSize: 11, fontWeight: 700,
    color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em',
  },
  tableRow: {
    display: 'flex', padding: '14px 16px', borderBottom: `1px solid ${colors.borderLight}`,
    cursor: 'pointer', transition: 'background 0.15s', alignItems: 'center',
  },
  tableRowExpanded: { background: colors.primaryBgLight },
  tableCell: { display: 'flex', alignItems: 'center', gap: 5 },
  alertId: { fontSize: 11, color: colors.textFaint, fontWeight: 500 },
  alertMessage: { fontSize: 13, color: colors.text, fontWeight: 500 },
  alertSource: { fontSize: 11, color: colors.textFaint, display: 'flex', alignItems: 'center', gap: 4 },
  severityBadge: { padding: '3px 9px', borderRadius: 5, fontSize: 10, fontWeight: 700, letterSpacing: '0.03em' },
  statusBadge: { display: 'flex', alignItems: 'center', gap: 4, padding: '3px 9px', borderRadius: 5, fontSize: 11, fontWeight: 600 },
  expandedRow: { background: colors.neutralBg, padding: 16, borderBottom: `1px solid ${colors.borderLight}` },
  expandedGrid: { display: 'flex', gap: 28, marginBottom: 14, flexWrap: 'wrap' },
  expandedItem: { display: 'flex', flexDirection: 'column', gap: 3 },
  expandedLabel: { fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 },
  expandedValue: { fontSize: 13, color: colors.text, fontWeight: 500 },
  actionButtons: { display: 'flex', gap: 10, flexWrap: 'wrap' },
  actionBtnPrimary: {
    display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px',
    background: colors.success, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: '#fff',
  },
  actionBtnInvestigate: {
    display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px',
    background: colors.primaryBg, border: `1px solid ${colors.primaryBorder}`, borderRadius: 7, fontSize: 12, fontWeight: 600, color: colors.primary,
  },
  actionBtnIgnore: {
    display: 'flex', alignItems: 'center', gap: 6, padding: '8px 14px',
    background: colors.criticalBg, border: 'none', borderRadius: 7, fontSize: 12, fontWeight: 600, color: colors.critical,
  },
  readOnlyNotice: {
    display: 'flex', alignItems: 'center', gap: 8, padding: '10px 14px',
    background: colors.primaryBg, borderRadius: 8, fontSize: 12, color: colors.primary, fontWeight: 500,
  },
  emptyState: {
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    padding: '56px 24px', background: '#fff', borderRadius: 12, border: `1px solid ${colors.border}`, gap: 14,
  },
  emptyText: { fontSize: 14, color: colors.textMuted },
}
