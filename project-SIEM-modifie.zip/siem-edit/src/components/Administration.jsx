import { useState } from 'react'
import { colors, roleConfig } from '../theme'

const mockUsers = [
  { id: 1, name: 'Jack Bauer', email: 'jack.bauer@ctu.gov', role: 'admin', status: 'actif', lastLogin: '2024-06-24 14:32' },
  { id: 2, name: 'Chloe O\'Brian', email: 'chloe.obrian@ctu.gov', role: 'analyste', status: 'actif', lastLogin: '2024-06-24 14:28' },
  { id: 3, name: 'Marie Martin', email: 'marie.martin@ctu.gov', role: 'lecteur', status: 'actif', lastLogin: '2024-06-24 13:55' },
  { id: 4, name: 'Pierre Durand', email: 'pierre.durand@ctu.gov', role: 'analyste', status: 'suspendu', lastLogin: '2024-06-23 18:12' },
  { id: 5, name: 'Sophie Bernard', email: 'sophie.bernard@ctu.gov', role: 'lecteur', status: 'actif', lastLogin: '2024-06-24 12:30' },
]

export default function Administration({ user, onAddUser, newUsers = [] }) {
  // On combine la liste mockée avec les comptes ajoutés en session (pas de useState
  // ici : on veut que la liste se mette à jour dès que newUsers change, par ex. juste
  // après la création d'un utilisateur depuis le formulaire CreerCompte).
  const users = [...mockUsers, ...newUsers]
  const [search, setSearch] = useState('')
  const [roleFilter, setRoleFilter] = useState('tous')
  const canManageUsers = roleConfig[user?.role]?.canManageUsers || false

  const filtered = users.filter(u => {
    const ms = u.name.toLowerCase().includes(search.toLowerCase()) || u.email.toLowerCase().includes(search.toLowerCase())
    const mr = roleFilter === 'tous' || u.role === roleFilter
    return ms && mr
  })

  const stats = {
    total: users.length,
    admin: users.filter(u => u.role === 'admin').length,
    analyste: users.filter(u => u.role === 'analyste').length,
    lecteur: users.filter(u => u.role === 'lecteur').length,
  }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Administration</h1>
          <p style={styles.subtitle}>Gestion des utilisateurs et des accès (RBAC)</p>
        </div>
        {canManageUsers && (
          <button style={styles.addBtn} onClick={onAddUser}>
            <i className="ti ti-user-plus" style={{ fontSize: 15 }} />
            Ajouter un utilisateur
          </button>
        )}
      </div>

      <div className="grid-4" style={styles.statsRow}>
        <div style={styles.statCard}>
          <div style={{ ...styles.statIcon, background: colors.primaryBg }}>
            <i className="ti ti-users" style={{ fontSize: 20, color: colors.primary }} />
          </div>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Total</span>
            <span style={styles.statValue}>{stats.total}</span>
          </div>
        </div>
        <div style={styles.statCard}>
          <div style={{ ...styles.statIcon, background: colors.purpleBg }}>
            <i className="ti ti-settings" style={{ fontSize: 20, color: colors.purple }} />
          </div>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Admins</span>
            <span style={styles.statValue}>{stats.admin}</span>
          </div>
        </div>
        <div style={styles.statCard}>
          <div style={{ ...styles.statIcon, background: colors.highBg }}>
            <i className="ti ti-search" style={{ fontSize: 20, color: colors.high }} />
          </div>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Analystes</span>
            <span style={styles.statValue}>{stats.analyste}</span>
          </div>
        </div>
        <div style={styles.statCard}>
          <div style={{ ...styles.statIcon, background: colors.successBg }}>
            <i className="ti ti-eye" style={{ fontSize: 20, color: colors.success }} />
          </div>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Lecteurs</span>
            <span style={styles.statValue}>{stats.lecteur}</span>
          </div>
        </div>
      </div>

      <div style={styles.tableCard}>
        <div style={styles.tableHeader}>
          <div style={styles.searchWrapper}>
            <i className="ti ti-search" style={styles.searchIcon} />
            <input
              type="text"
              placeholder="Rechercher un utilisateur..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              style={styles.searchInput}
            />
          </div>
          <select value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)} style={styles.select}>
            <option value="tous">Tous les rôles</option>
            <option value="admin">Admin</option>
            <option value="analyste">Analyste</option>
            <option value="lecteur">Lecteur</option>
          </select>
        </div>

        <div style={styles.table}>
          <div style={styles.thead}>
            <div style={{ ...styles.th, flex: '0 0 50px' }}>ID</div>
            <div style={{ ...styles.th, flex: 2 }}>Utilisateur</div>
            <div style={{ ...styles.th, flex: '0 0 120px' }}>Rôle</div>
            <div style={{ ...styles.th, flex: '0 0 100px' }}>Statut</div>
            <div style={{ ...styles.th, flex: '0 0 140px' }}>Dernière connexion</div>
            <div style={{ ...styles.th, flex: '0 0 80px' }}>Actions</div>
          </div>

          {filtered.map((u) => {
            const rc = roleConfig[u.role]
            return (
              <div key={u.id} style={styles.tr}>
                <div style={{ ...styles.td, flex: '0 0 50px' }}>
                  <span className="mono" style={styles.userId}>#{u.id}</span>
                </div>
                <div style={{ ...styles.td, flex: 2, gap: 10 }}>
                  <div style={styles.avatar}>{u.name.charAt(0)}</div>
                  <div style={styles.userMeta}>
                    <span style={styles.userName}>{u.name}</span>
                    <span style={styles.userEmail}>{u.email}</span>
                  </div>
                </div>
                <div style={{ ...styles.td, flex: '0 0 120px' }}>
                  <span style={{ ...styles.roleBadge, background: `${rc === roleConfig.admin ? colors.purpleBg : rc === roleConfig.analyste ? colors.highBg : colors.successBg}`, color: rc === roleConfig.admin ? colors.purple : rc === roleConfig.analyste ? colors.high : colors.success }}>
                    <i className={`ti ${rc.icon}`} style={{ fontSize: 11 }} />
                    {rc.label}
                  </span>
                </div>
                <div style={{ ...styles.td, flex: '0 0 100px' }}>
                  <span style={{ ...styles.statusBadge, background: u.status === 'actif' ? colors.successBg : colors.criticalBg, color: u.status === 'actif' ? colors.success : colors.critical }}>
                    <span style={{ ...styles.statusDot, background: u.status === 'actif' ? colors.success : colors.critical }} />
                    {u.status === 'actif' ? 'Actif' : 'Suspendu'}
                  </span>
                </div>
                <div style={{ ...styles.td, flex: '0 0 140px', fontSize: 12, color: colors.textFaint }}>
                  <i className="ti ti-clock" style={{ fontSize: 12, marginRight: 4 }} />
                  {u.lastLogin}
                </div>
                <div style={{ ...styles.td, flex: '0 0 80px', gap: 6 }}>
                  <button style={styles.actionBtn} title="Modifier">
                    <i className="ti ti-edit" style={{ fontSize: 14 }} />
                  </button>
                  <button style={{ ...styles.actionBtn, color: colors.critical }} title="Supprimer">
                    <i className="ti ti-trash" style={{ fontSize: 14 }} />
                  </button>
                </div>
              </div>
            )
          })}
        </div>
      </div>

      <div style={styles.permCard}>
        <h3 style={styles.permTitle}>
          <i className="ti ti-shield-lock" style={{ fontSize: 16 }} />
          Matrice des permissions (RBAC)
        </h3>
        <div style={styles.permTable}>
          <div style={styles.permHead}>
            <div style={{ ...styles.permTh, flex: 2 }}>Permission</div>
            <div style={{ ...styles.permTh, flex: 1, textAlign: 'center' }}>Lecteur</div>
            <div style={{ ...styles.permTh, flex: 1, textAlign: 'center' }}>Analyste</div>
            <div style={{ ...styles.permTh, flex: 1, textAlign: 'center' }}>Admin</div>
          </div>
          {[
            { perm: 'Consulter le dashboard', l: true, a: true, ad: true },
            { perm: 'Rechercher dans les logs', l: true, a: true, ad: true },
            { perm: 'Consulter les alertes', l: true, a: true, ad: true },
            { perm: 'Consulter l\'UEBA', l: true, a: true, ad: true },
            { perm: 'Consulter les rapports', l: true, a: true, ad: true },
            { perm: 'Exporter les données', l: false, a: true, ad: true },
            { perm: 'Acquitter / résoudre des alertes', l: false, a: true, ad: true },
            { perm: 'Investiguer les incidents', l: false, a: true, ad: true },
            { perm: 'Générer des rapports', l: false, a: true, ad: true },
            { perm: 'Gérer les utilisateurs', l: false, a: false, ad: true },
            { perm: 'Modifier les rôles et permissions', l: false, a: false, ad: true },
          ].map((row, i) => (
            <div key={i} style={styles.permRow}>
              <div style={{ ...styles.permTd, flex: 2 }}>{row.perm}</div>
              <div style={{ ...styles.permTd, flex: 1, textAlign: 'center' }}>
                <i className={`ti ${row.l ? 'ti-check' : 'ti-x'}`} style={{ fontSize: 15, color: row.l ? colors.success : colors.textLight }} />
              </div>
              <div style={{ ...styles.permTd, flex: 1, textAlign: 'center' }}>
                <i className={`ti ${row.a ? 'ti-check' : 'ti-x'}`} style={{ fontSize: 15, color: row.a ? colors.success : colors.textLight }} />
              </div>
              <div style={{ ...styles.permTd, flex: 1, textAlign: 'center' }}>
                <i className={`ti ${row.ad ? 'ti-check' : 'ti-x'}`} style={{ fontSize: 15, color: row.ad ? colors.success : colors.textLight }} />
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

const styles = {
  container: { display: 'flex', flexDirection: 'column', gap: 20 },
  header: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 14 },
  title: { fontSize: 24, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  subtitle: { fontSize: 13, color: colors.textMuted, marginTop: 3 },
  addBtn: {
    display: 'flex', alignItems: 'center', gap: 7, padding: '9px 14px',
    background: colors.primary, border: 'none', borderRadius: 8, fontSize: 13, fontWeight: 600, color: '#fff',
  },
  statsRow: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 },
  statCard: { background: '#fff', borderRadius: 12, padding: 18, display: 'flex', gap: 14, alignItems: 'center', border: `1px solid ${colors.border}` },
  statIcon: { width: 42, height: 42, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  statContent: { display: 'flex', flexDirection: 'column', gap: 4 },
  statLabel: { fontSize: 12, color: colors.textMuted, fontWeight: 500 },
  statValue: { fontSize: 24, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  tableCard: { background: '#fff', borderRadius: 12, border: `1px solid ${colors.border}`, overflow: 'hidden' },
  tableHeader: { display: 'flex', gap: 12, padding: 14, borderBottom: `1px solid ${colors.borderLight}`, flexWrap: 'wrap', alignItems: 'center' },
  searchWrapper: { position: 'relative', flex: 1, minWidth: 200 },
  searchIcon: { position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 16, color: colors.textFaint },
  searchInput: { width: '100%', padding: '10px 12px 10px 40px', border: `1px solid ${colors.neutralBorder}`, borderRadius: 8, fontSize: 13, background: colors.neutralBg, color: colors.text, outline: 'none' },
  select: {
    padding: '9px 30px 9px 12px', border: `1px solid ${colors.neutralBorder}`, borderRadius: 8, fontSize: 13, background: '#fff', cursor: 'pointer', appearance: 'none',
    backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2212%22%20height%3D%2212%22%3E%3Cpath%20fill%3D%22%2364748b%22%20d%3D%22M6%208L1%203h10z%22/%3E%3C/svg%3E")',
    backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center',
  },
  table: {},
  thead: { display: 'flex', padding: '12px 16px', background: colors.neutralBg, borderBottom: `1px solid ${colors.border}`, fontSize: 11, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em' },
  th: { display: 'flex', alignItems: 'center' },
  tr: { display: 'flex', padding: '14px 16px', borderBottom: `1px solid ${colors.borderLight}`, alignItems: 'center' },
  td: { display: 'flex', alignItems: 'center' },
  userId: { fontSize: 11, color: colors.textFaint, fontWeight: 500 },
  avatar: { width: 34, height: 34, borderRadius: '50%', background: `linear-gradient(135deg, ${colors.primary}, ${colors.primaryLight})`, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, flexShrink: 0 },
  userMeta: { display: 'flex', flexDirection: 'column', gap: 2 },
  userName: { fontSize: 13, fontWeight: 600, color: colors.text },
  userEmail: { fontSize: 11, color: colors.textFaint },
  roleBadge: { display: 'flex', alignItems: 'center', gap: 4, padding: '4px 9px', borderRadius: 6, fontSize: 11, fontWeight: 600 },
  statusBadge: { display: 'flex', alignItems: 'center', gap: 5, padding: '4px 9px', borderRadius: 6, fontSize: 11, fontWeight: 600 },
  statusDot: { width: 6, height: 6, borderRadius: '50%' },
  actionBtn: { background: 'transparent', border: 'none', padding: 6, borderRadius: 6, color: colors.textMuted, display: 'flex', alignItems: 'center' },
  permCard: { background: '#fff', borderRadius: 12, padding: 18, border: `1px solid ${colors.border}` },
  permTitle: { display: 'flex', alignItems: 'center', gap: 7, fontSize: 15, fontWeight: 700, color: colors.text, marginBottom: 14 },
  permTable: {},
  permHead: { display: 'flex', padding: '10px 14px', background: colors.neutralBg, borderRadius: 8, marginBottom: 4 },
  permTh: { fontSize: 11, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em' },
  permRow: { display: 'flex', padding: '10px 14px', borderBottom: `1px solid ${colors.borderLight}`, alignItems: 'center' },
  permTd: { fontSize: 13, color: colors.textBody },
}
