import { useState } from 'react'
import { colors, severityConfig } from '../theme'

const mockResults = [
  { id: 'EVT-2024-06-001', type: 'evenement', title: 'Tentative d\'accès refusé — Firewall', timestamp: '2024-06-24 14:32:15', source: 'Firewall-Principal', ip: '192.168.1.45', details: 'Tentative de connexion SSH depuis une IP non autorisée', severity: 'high' },
  { id: 'LOG-2024-06-002', type: 'log', title: 'Connexion utilisateur réussie', timestamp: '2024-06-24 14:28:03', source: 'Auth-Service', user: 'jean.dupont', ip: '10.0.0.15', details: 'Authentification réussie via LDAP', severity: 'info' },
  { id: 'ALR-2024-06-003', type: 'alerte', title: 'Scan de ports détecté', timestamp: '2024-06-24 13:55:42', source: 'IDS-Sensor-01', ip: '172.16.0.100', details: 'Scan SYN détecté sur les ports 22, 80, 443', severity: 'warning' },
  { id: 'EVT-2024-06-004', type: 'evenement', title: 'Accès fichier sensible', timestamp: '2024-06-24 13:42:18', source: 'DLP-Agent', user: 'marie.martin', file: '/confidentiel/rapport_q2.pdf', details: 'Accès à un fichier marqué comme confidentiel', severity: 'warning' },
  { id: 'LOG-2024-06-005', type: 'log', title: 'Modification configuration serveur', timestamp: '2024-06-24 12:30:55', source: 'Server-DB-01', user: 'admin', details: 'Modification du fichier postgresql.conf', severity: 'info' },
  { id: 'ALR-2024-06-006', type: 'alerte', title: 'Trafic sortant anormal', timestamp: '2024-06-24 12:15:33', source: 'Network-Monitor', ip: '192.168.1.78', details: 'Volume de données sortant supérieur à 500MB en 10 minutes', severity: 'high' },
  { id: 'EVT-2024-06-007', type: 'evenement', title: 'Processus injecté détecté', timestamp: '2024-06-24 11:45:12', source: 'EDR-Agent', ip: '192.168.1.95', details: 'Injection de processus suspect (pid=4421)', severity: 'critical' },
  { id: 'LOG-2024-06-008', type: 'log', title: 'Requête DNS suspecte', timestamp: '2024-06-24 11:20:08', source: 'DNS-Server', ip: '192.168.1.78', details: 'Query: c2-malicious.example.com', severity: 'high' },
]

const typeConfig = {
  evenement: { icon: 'ti-server', color: colors.primary, label: 'Événement' },
  log: { icon: 'ti-file-text', color: colors.textFaint, label: 'Log' },
  alerte: { icon: 'ti-bell', color: colors.critical, label: 'Alerte' },
}

export default function Recherche() {
  const [query, setQuery] = useState('')
  const [results, setResults] = useState([])
  const [hasSearched, setHasSearched] = useState(false)
  const [filters, setFilters] = useState({ type: 'tous', period: '24h', severity: 'tous' })
  const [expandedResult, setExpandedResult] = useState(null)

  const handleSearch = () => {
    if (!query.trim()) return
    const filtered = mockResults.filter(r => {
      const matchesQuery = r.title.toLowerCase().includes(query.toLowerCase()) ||
        r.id.toLowerCase().includes(query.toLowerCase()) ||
        r.ip?.includes(query) ||
        r.user?.toLowerCase().includes(query.toLowerCase()) ||
        r.details.toLowerCase().includes(query.toLowerCase())
      const matchesType = filters.type === 'tous' || r.type === filters.type
      const matchesSeverity = filters.severity === 'tous' || r.severity === filters.severity
      return matchesQuery && matchesType && matchesSeverity
    })
    setResults(filtered)
    setHasSearched(true)
  }

  const handleKeyPress = (e) => { if (e.key === 'Enter') handleSearch() }
  const clearSearch = () => { setQuery(''); setResults([]); setHasSearched(false) }

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <h1 style={styles.title}>Recherche</h1>
        <p style={styles.subtitle}>Recherchez dans les événements, logs et alertes</p>
      </div>

      <div style={styles.searchCard}>
        <div style={styles.searchRow}>
          <div style={styles.searchWrapper}>
            <i className="ti ti-search" style={styles.searchIcon} />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyPress={handleKeyPress}
              placeholder="Rechercher par IP, utilisateur, ID, message..."
              style={styles.searchInput}
            />
            {query && (
              <button onClick={clearSearch} style={styles.clearBtn}>
                <i className="ti ti-x" style={{ fontSize: 16 }} />
              </button>
            )}
          </div>
          <button onClick={handleSearch} style={styles.searchBtn}>
            <i className="ti ti-search" style={{ fontSize: 16 }} />
            Rechercher
          </button>
        </div>
      </div>

      <div className="search-layout" style={styles.layout}>
        <div className="search-sidebar" style={styles.sidebar}>
          <div style={styles.sidebarCard}>
            <h3 style={styles.sidebarTitle}>
              <i className="ti ti-filter" style={{ fontSize: 15 }} />
              Filtres
            </h3>

            <div style={styles.filterGroup}>
              <label style={styles.filterLabel}>Type</label>
              <select value={filters.type} onChange={(e) => setFilters({ ...filters, type: e.target.value })} style={styles.select}>
                <option value="tous">Tous les types</option>
                <option value="evenement">Événements</option>
                <option value="log">Logs</option>
                <option value="alerte">Alertes</option>
              </select>
            </div>

            <div style={styles.filterGroup}>
              <label style={styles.filterLabel}>Période</label>
              <select value={filters.period} onChange={(e) => setFilters({ ...filters, period: e.target.value })} style={styles.select}>
                <option value="1h">Dernière heure</option>
                <option value="24h">24 dernières heures</option>
                <option value="7j">7 derniers jours</option>
                <option value="30j">30 derniers jours</option>
              </select>
            </div>

            <div style={styles.filterGroup}>
              <label style={styles.filterLabel}>Sévérité</label>
              <select value={filters.severity} onChange={(e) => setFilters({ ...filters, severity: e.target.value })} style={styles.select}>
                <option value="tous">Toutes sévérités</option>
                <option value="critical">Critique</option>
                <option value="high">Haute</option>
                <option value="warning">Moyenne</option>
                <option value="info">Info</option>
              </select>
            </div>
          </div>

          <div style={styles.sidebarCard}>
            <h3 style={styles.sidebarTitle}>
              <i className="ti ti-bulb" style={{ fontSize: 15 }} />
              Recherches populaires
            </h3>
            <div style={styles.popularTags}>
              {['échec authentification', '192.168.1', 'admin', 'scan', 'accès refusé'].map((tag) => (
                <button key={tag} onClick={() => { setQuery(tag); setHasSearched(false) }} style={styles.popularTag}>
                  {tag}
                </button>
              ))}
            </div>
          </div>

          <div style={styles.sidebarCard}>
            <h3 style={styles.sidebarTitle}>
              <i className="ti ti-info-circle" style={{ fontSize: 15 }} />
              Conseils
            </h3>
            <ul style={styles.helpList}>
              <li>Utilisez des mots-clés spécifiques : IP, utilisateur, ID</li>
              <li>Recherche non sensible à la casse</li>
              <li>Affinez avec les filtres à gauche</li>
              <li>Résultats triés par date décroissante</li>
            </ul>
          </div>
        </div>

        <div style={styles.resultsSection}>
          {hasSearched ? (
            <>
              <div style={styles.resultsHeader}>
                <span style={styles.resultsCount}>
                  {results.length} résultat{results.length !== 1 ? 's' : ''} trouvé{results.length !== 1 ? 's' : ''}
                </span>
              </div>

              {results.length > 0 ? (
                <div style={styles.resultsList}>
                  {results.map((result) => {
                    const tc = typeConfig[result.type]
                    const sev = severityConfig[result.severity]
                    return (
                      <div
                        key={result.id}
                        style={styles.resultCard}
                        onClick={() => setExpandedResult(expandedResult === result.id ? null : result.id)}
                      >
                        <div style={styles.resultHeader}>
                          <div style={styles.resultType}>
                            <div style={{ ...styles.typeIcon, background: `${tc.color}15` }}>
                              <i className={`ti ${tc.icon}`} style={{ fontSize: 16, color: tc.color }} />
                            </div>
                            <div style={styles.resultInfo}>
                              <span className="mono" style={styles.resultId}>{result.id}</span>
                              <span style={styles.resultTitle}>{result.title}</span>
                            </div>
                          </div>
                          <span style={{ ...styles.severityBadge, background: sev.bg, color: sev.color }}>
                            {sev.label}
                          </span>
                        </div>

                        <div style={styles.resultMeta}>
                          <span style={styles.metaItem}>
                            <i className="ti ti-clock" style={{ fontSize: 12 }} />
                            {result.timestamp}
                          </span>
                          <span style={styles.metaItem}>
                            <i className="ti ti-server" style={{ fontSize: 12 }} />
                            {result.source}
                          </span>
                          {result.ip && (
                            <span style={styles.metaItem}>
                              <i className="ti ti-world" style={{ fontSize: 12 }} />
                              <span className="mono">{result.ip}</span>
                            </span>
                          )}
                          {result.user && (
                            <span style={styles.metaItem}>
                              <i className="ti ti-user" style={{ fontSize: 12 }} />
                              {result.user}
                            </span>
                          )}
                        </div>

                        {expandedResult === result.id && (
                          <div style={styles.expandedContent}>
                            <div style={styles.divider} />
                            <div style={styles.detailsGrid}>
                              <div style={styles.detailItem}>
                                <span style={styles.detailLabel}>Détails</span>
                                <span style={styles.detailValue}>{result.details}</span>
                              </div>
                              {result.file && (
                                <div style={styles.detailItem}>
                                  <span style={styles.detailLabel}>Fichier</span>
                                  <span className="mono" style={styles.detailValue}>{result.file}</span>
                                </div>
                              )}
                              <div style={styles.detailItem}>
                                <span style={styles.detailLabel}>Type</span>
                                <span style={styles.detailValue}>{tc.label}</span>
                              </div>
                            </div>
                          </div>
                        )}
                      </div>
                    )
                  })}
                </div>
              ) : (
                <div style={styles.emptyState}>
                  <i className="ti ti-search" style={{ fontSize: 40, color: colors.textLight }} />
                  <p style={styles.emptyText}>Aucun résultat pour "{query}"</p>
                  <p style={styles.emptyHint}>Essayez avec d'autres termes ou modifiez vos filtres</p>
                </div>
              )}
            </>
          ) : (
            <div style={styles.welcomeState}>
              <div style={styles.welcomeIcon}>
                <i className="ti ti-search" style={{ fontSize: 36, color: colors.primary }} />
              </div>
              <h3 style={styles.welcomeTitle}>Recherche dans les logs</h3>
              <p style={styles.welcomeText}>
                Saisissez une requête pour rechercher dans les événements, logs et alertes.
                Utilisez les filtres pour affiner vos résultats.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

const styles = {
  container: { display: 'flex', flexDirection: 'column', gap: 18 },
  header: {},
  title: { fontSize: 24, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  subtitle: { fontSize: 13, color: colors.textMuted, marginTop: 3 },
  searchCard: { background: '#fff', borderRadius: 12, padding: 16, border: `1px solid ${colors.border}` },
  searchRow: { display: 'flex', gap: 10 },
  searchWrapper: { position: 'relative', flex: 1 },
  searchIcon: { position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)', fontSize: 18, color: colors.textFaint },
  searchInput: {
    width: '100%', padding: '13px 40px 13px 44px', border: `1px solid ${colors.neutralBorder}`,
    borderRadius: 9, fontSize: 14, background: colors.neutralBg, color: colors.text, outline: 'none',
  },
  clearBtn: {
    position: 'absolute', right: 12, top: '50%', transform: 'translateY(-50%)',
    background: 'none', border: 'none', padding: 4, color: colors.textFaint, display: 'flex',
  },
  searchBtn: {
    display: 'flex', alignItems: 'center', gap: 7, padding: '13px 24px',
    background: colors.primary, border: 'none', borderRadius: 9, fontSize: 14, fontWeight: 600, color: '#fff',
  },
  layout: { display: 'grid', gridTemplateColumns: '260px 1fr', gap: 16 },
  sidebar: { display: 'flex', flexDirection: 'column', gap: 14 },
  sidebarCard: { background: '#fff', borderRadius: 12, padding: 16, border: `1px solid ${colors.border}` },
  sidebarTitle: { display: 'flex', alignItems: 'center', gap: 7, fontSize: 14, fontWeight: 700, color: colors.text, marginBottom: 14 },
  filterGroup: { display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 14 },
  filterLabel: { fontSize: 11, color: colors.textFaint, fontWeight: 600, textTransform: 'uppercase', letterSpacing: '0.05em' },
  select: {
    padding: '9px 30px 9px 12px', border: `1px solid ${colors.neutralBorder}`, borderRadius: 8,
    fontSize: 13, background: colors.neutralBg, color: colors.text, cursor: 'pointer', appearance: 'none',
    backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2212%22%20height%3D%2212%22%3E%3Cpath%20fill%3D%22%2364748b%22%20d%3D%22M6%208L1%203h10z%22/%3E%3C/svg%3E")',
    backgroundRepeat: 'no-repeat', backgroundPosition: 'right 10px center',
  },
  popularTags: { display: 'flex', gap: 7, flexWrap: 'wrap' },
  popularTag: {
    padding: '6px 12px', background: colors.neutralBg, border: `1px solid ${colors.neutralBorder}`,
    borderRadius: 16, fontSize: 12, color: colors.textBody,
  },
  helpList: { margin: 0, padding: '0 0 0 18px', color: colors.textMuted, fontSize: 12, lineHeight: 1.8 },
  resultsSection: { display: 'flex', flexDirection: 'column', gap: 12 },
  resultsHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  resultsCount: { fontSize: 13, color: colors.textMuted, fontWeight: 500 },
  resultsList: { display: 'flex', flexDirection: 'column', gap: 10 },
  resultCard: {
    background: '#fff', borderRadius: 12, padding: 16, border: `1px solid ${colors.border}`,
    cursor: 'pointer', transition: 'all 0.15s',
  },
  resultHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
  resultType: { display: 'flex', gap: 12, alignItems: 'flex-start' },
  typeIcon: { width: 36, height: 36, borderRadius: 8, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 },
  resultInfo: { display: 'flex', flexDirection: 'column', gap: 3 },
  resultId: { fontSize: 11, color: colors.textFaint },
  resultTitle: { fontSize: 14, fontWeight: 600, color: colors.text },
  severityBadge: { padding: '3px 9px', borderRadius: 5, fontSize: 10, fontWeight: 700, whiteSpace: 'nowrap', letterSpacing: '0.03em' },
  resultMeta: { display: 'flex', gap: 16, marginTop: 12, flexWrap: 'wrap' },
  metaItem: { display: 'flex', alignItems: 'center', gap: 5, fontSize: 12, color: colors.textMuted },
  expandedContent: { marginTop: 12 },
  divider: { height: 1, background: colors.borderLight, marginBottom: 12 },
  detailsGrid: { display: 'flex', gap: 24, flexWrap: 'wrap' },
  detailItem: { display: 'flex', flexDirection: 'column', gap: 3 },
  detailLabel: { fontSize: 10, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 },
  detailValue: { fontSize: 13, color: colors.text },
  emptyState: {
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    padding: '56px 24px', background: '#fff', borderRadius: 12, border: `1px solid ${colors.border}`, gap: 10,
  },
  emptyText: { fontSize: 15, fontWeight: 600, color: colors.text },
  emptyHint: { fontSize: 13, color: colors.textMuted },
  welcomeState: {
    display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center',
    padding: '64px 24px', background: '#fff', borderRadius: 12, border: `1px solid ${colors.border}`, gap: 14, textAlign: 'center',
  },
  welcomeIcon: {
    width: 72, height: 72, borderRadius: 18, background: colors.primaryBg,
    display: 'flex', alignItems: 'center', justifyContent: 'center',
  },
  welcomeTitle: { fontSize: 18, fontWeight: 700, color: colors.text },
  welcomeText: { fontSize: 13, color: colors.textMuted, maxWidth: 400, lineHeight: 1.6 },
}
