import { useState } from 'react'
import { colors, severityConfig } from '../theme'
import {
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar,
} from 'recharts'

const behaviorScores = [
  { subject: 'Connexions', A: 85, fullMark: 100 },
  { subject: 'Accès fichiers', A: 72, fullMark: 100 },
  { subject: 'Heures actives', A: 90, fullMark: 100 },
  { subject: 'Localisation', A: 95, fullMark: 100 },
  { subject: 'Appareils', A: 88, fullMark: 100 },
  { subject: 'Volume données', A: 78, fullMark: 100 },
]

const hourlyActivity = [
  { hour: '00', activity: 5 },
  { hour: '04', activity: 2 },
  { hour: '08', activity: 35 },
  { hour: '12', activity: 60 },
  { hour: '16', activity: 45 },
  { hour: '20', activity: 15 },
]

const mockUsers = [
  { id: 1, name: 'Lucas Petit', email: 'lucas.petit@company.com', department: 'IT', riskScore: 92, status: 'critique', lastActivity: '2024-06-24 14:15', anomalies: ['Tentative d\'escalade de privilèges', 'Accès à des serveurs non autorisés', 'Modification de configurations système', 'Suppression de logs'] },
  { id: 2, name: 'Jean Dupont', email: 'jean.dupont@company.com', department: 'IT', riskScore: 85, status: 'risque', lastActivity: '2024-06-24 14:32', anomalies: ['Connexion depuis un nouveau pays', 'Accès à des fichiers inhabituels', 'Activité hors heures normales'] },
  { id: 3, name: 'Pierre Durand', email: 'pierre.durand@company.com', department: 'Finance', riskScore: 72, status: 'attention', lastActivity: '2024-06-24 13:55', anomalies: ['Multiples échecs d\'authentification'] },
  { id: 4, name: 'Marie Martin', email: 'marie.martin@company.com', department: 'RH', riskScore: 45, status: 'normal', lastActivity: '2024-06-24 14:28', anomalies: [] },
  { id: 5, name: 'Sophie Bernard', email: 'sophie.bernard@company.com', department: 'Marketing', riskScore: 25, status: 'normal', lastActivity: '2024-06-24 12:30', anomalies: [] },
]

const statusConfig = {
  normal: { label: 'Normal', color: colors.success, bg: colors.successBg, icon: 'ti-user-check' },
  attention: { label: 'Attention', color: colors.warning, bg: colors.warningBg, icon: 'ti-alert-triangle' },
  risque: { label: 'Risque', color: colors.high, bg: colors.highBg, icon: 'ti-trending-up' },
  critique: { label: 'Critique', color: colors.critical, bg: colors.criticalBg, icon: 'ti-user-x' },
}

export default function UEBA() {
  const [selectedUser, setSelectedUser] = useState(null)
  const [statusFilter, setStatusFilter] = useState('tous')
  const [sortOrder, setSortOrder] = useState('desc')

  const filteredUsers = mockUsers
    .filter(u => statusFilter === 'tous' || u.status === statusFilter)
    .sort((a, b) => sortOrder === 'desc' ? b.riskScore - a.riskScore : a.riskScore - b.riskScore)

  const stats = {
    total: mockUsers.length,
    normal: mockUsers.filter(u => u.status === 'normal').length,
    attention: mockUsers.filter(u => u.status === 'attention').length,
    risque: mockUsers.filter(u => ['risque', 'critique'].includes(u.status)).length,
  }
  const avgRiskScore = Math.round(mockUsers.reduce((s, u) => s + u.riskScore, 0) / mockUsers.length)

  return (
    <div style={styles.container}>
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>UEBA — Analyse comportementale</h1>
          <p style={styles.subtitle}>Détection d'anomalies dans le comportement des utilisateurs</p>
        </div>
      </div>

      <div className="grid-4" style={styles.statsRow}>
        <div style={styles.statCard}>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Utilisateurs analysés</span>
            <span style={styles.statValue}>{stats.total}</span>
          </div>
          <div style={{ ...styles.statIcon, background: colors.primaryBg }}>
            <i className="ti ti-users" style={{ fontSize: 22, color: colors.primary }} />
          </div>
        </div>
        <div style={{ ...styles.statCard, background: colors.successBg }}>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Comportement normal</span>
            <span style={{ ...styles.statValue, color: colors.success }}>{stats.normal}</span>
          </div>
          <i className="ti ti-user-check" style={{ fontSize: 22, color: colors.success }} />
        </div>
        <div style={{ ...styles.statCard, background: colors.warningBg }}>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>À surveiller</span>
            <span style={{ ...styles.statValue, color: colors.warning }}>{stats.attention}</span>
          </div>
          <i className="ti ti-alert-triangle" style={{ fontSize: 22, color: colors.warning }} />
        </div>
        <div style={{ ...styles.statCard, background: colors.criticalBg }}>
          <div style={styles.statContent}>
            <span style={styles.statLabel}>Comportements risqués</span>
            <span style={{ ...styles.statValue, color: colors.critical }}>{stats.risque}</span>
          </div>
          <i className="ti ti-shield" style={{ fontSize: 22, color: colors.critical }} />
        </div>
      </div>

      <div className="main-grid-2" style={styles.mainGrid}>
        <div style={styles.userListSection}>
          <div style={styles.listHeader}>
            <h2 style={styles.sectionTitle}>Profils utilisateurs</h2>
            <div style={styles.listActions}>
              <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} style={styles.select}>
                <option value="tous">Tous les statuts</option>
                <option value="normal">Normal</option>
                <option value="attention">Attention</option>
                <option value="risque">Risque</option>
                <option value="critique">Critique</option>
              </select>
              <button onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')} style={styles.sortBtn}>
                Risque <i className={`ti ${sortOrder === 'desc' ? 'ti-sort-descending' : 'ti-sort-ascending'}`} style={{ fontSize: 13 }} />
              </button>
            </div>
          </div>

          <div style={styles.userList}>
            {filteredUsers.map((user) => {
              const sc = statusConfig[user.status]
              return (
                <div
                  key={user.id}
                  onClick={() => setSelectedUser(selectedUser?.id === user.id ? null : user)}
                  style={{
                    ...styles.userCard,
                    ...(selectedUser?.id === user.id ? styles.userCardSelected : {}),
                    borderLeft: `3px solid ${sc.color}`,
                  }}
                >
                  <div style={styles.userHeader}>
                    <div style={{ ...styles.avatar, background: sc.bg, color: sc.color }}>
                      {user.name.charAt(0)}
                    </div>
                    <div style={styles.userInfo}>
                      <span style={styles.userName}>{user.name}</span>
                      <span style={styles.userDept}>{user.department}</span>
                    </div>
                    <span style={{ ...styles.riskBadge, background: sc.bg, color: sc.color }}>
                      <i className={`ti ${sc.icon}`} style={{ fontSize: 12 }} />
                      {user.riskScore}
                    </span>
                  </div>
                  {selectedUser?.id === user.id && (
                    <div style={styles.userDetails}>
                      <div style={styles.anomaliesList}>
                        {user.anomalies.length > 0 ? (
                          <>
                            <span style={styles.anomaliesTitle}>Anomalies détectées</span>
                            {user.anomalies.map((anomaly, idx) => (
                              <div key={idx} style={styles.anomalyItem}>
                                <i className="ti ti-alert-triangle" style={{ fontSize: 13, color: colors.high }} />
                                {anomaly}
                              </div>
                            ))}
                          </>
                        ) : (
                          <span style={styles.noAnomaly}>
                            <i className="ti ti-circle-check" style={{ fontSize: 14 }} />
                            Aucune anomalie détectée
                          </span>
                        )}
                      </div>
                      <div style={styles.userMeta}>
                        <span style={styles.metaItem}>
                          <i className="ti ti-mail" style={{ fontSize: 12 }} />
                          {user.email}
                        </span>
                        <span style={styles.metaItem}>
                          <i className="ti ti-clock" style={{ fontSize: 12 }} />
                          {user.lastActivity}
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        </div>

        <div style={styles.analysisSection}>
          <div style={styles.chartCard}>
            <h3 style={styles.chartTitle}>Profil comportemental moyen</h3>
            <div style={styles.chartContainer}>
              <ResponsiveContainer width="100%" height={220}>
                <RadarChart data={behaviorScores}>
                  <PolarGrid stroke={colors.borderLight} />
                  <PolarAngleAxis dataKey="subject" tick={{ fontSize: 10, fill: colors.textMuted }} />
                  <PolarRadiusAxis angle={30} domain={[0, 100]} tick={{ fontSize: 9 }} />
                  <Radar name="Score" dataKey="A" stroke={colors.primary} fill={colors.primary} fillOpacity={0.25} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={styles.chartCard}>
            <h3 style={styles.chartTitle}>Activité horaire moyenne</h3>
            <div style={styles.chartContainer}>
              <ResponsiveContainer width="100%" height={180}>
                <LineChart data={hourlyActivity}>
                  <CartesianGrid strokeDasharray="3 3" stroke={colors.borderLight} />
                  <XAxis dataKey="hour" stroke={colors.textFaint} fontSize={10} tickLine={false} axisLine={false} />
                  <YAxis stroke={colors.textFaint} fontSize={10} tickLine={false} axisLine={false} />
                  <Tooltip contentStyle={tooltipStyle} />
                  <Line type="monotone" dataKey="activity" stroke={colors.primary} strokeWidth={2} dot={{ fill: colors.primary, strokeWidth: 0, r: 4 }} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div style={styles.summaryCard}>
            <h3 style={styles.chartTitle}>Résumé global</h3>
            <div style={styles.summaryContent}>
              <div style={styles.summaryItem}>
                <span style={styles.summaryLabel}>Score de risque moyen</span>
                <div style={styles.summaryValueRow}>
                  <span style={styles.summaryValue}>{avgRiskScore}/100</span>
                  <span style={{
                    ...styles.summaryTrend,
                    color: avgRiskScore < 50 ? colors.success : avgRiskScore < 70 ? colors.warning : colors.critical,
                    background: avgRiskScore < 50 ? colors.successBg : avgRiskScore < 70 ? colors.warningBg : colors.criticalBg,
                  }}>
                    {avgRiskScore < 50 ? 'Faible' : avgRiskScore < 70 ? 'Modéré' : 'Élevé'}
                  </span>
                </div>
              </div>
              <div style={styles.summaryItem}>
                <span style={styles.summaryLabel}>Taux d'anomalies</span>
                <div style={styles.summaryValueRow}>
                  <span style={styles.summaryValue}>12%</span>
                  <i className="ti ti-trending-down" style={{ fontSize: 16, color: colors.success }} />
                </div>
              </div>
              <div style={styles.summaryItem}>
                <span style={styles.summaryLabel}>Dernière analyse</span>
                <span style={styles.summaryValueSmall}>Il y a 5 minutes</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

const tooltipStyle = {
  backgroundColor: '#fff', border: `1px solid ${colors.border}`, borderRadius: 8, fontSize: 12,
}

const styles = {
  container: { display: 'flex', flexDirection: 'column', gap: 20 },
  header: {},
  title: { fontSize: 24, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  subtitle: { fontSize: 13, color: colors.textMuted, marginTop: 3 },
  statsRow: { display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14 },
  statCard: {
    background: '#fff', borderRadius: 12, padding: 18, display: 'flex',
    justifyContent: 'space-between', alignItems: 'center', border: `1px solid ${colors.border}`,
  },
  statContent: { display: 'flex', flexDirection: 'column', gap: 4 },
  statLabel: { fontSize: 12, color: colors.textMuted, fontWeight: 500 },
  statValue: { fontSize: 26, fontWeight: 700, color: colors.text, letterSpacing: '-0.5px' },
  statIcon: { width: 44, height: 44, borderRadius: 10, display: 'flex', alignItems: 'center', justifyContent: 'center' },
  mainGrid: { display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 20 },
  userListSection: { display: 'flex', flexDirection: 'column', gap: 14 },
  listHeader: { display: 'flex', justifyContent: 'space-between', alignItems: 'center' },
  sectionTitle: { fontSize: 16, fontWeight: 700, color: colors.text },
  listActions: { display: 'flex', gap: 10, alignItems: 'center' },
  select: {
    padding: '7px 26px 7px 11px', border: `1px solid ${colors.neutralBorder}`, borderRadius: 8,
    fontSize: 12, background: '#fff', color: colors.textBody, cursor: 'pointer', appearance: 'none',
    backgroundImage: 'url("data:image/svg+xml;charset=US-ASCII,%3Csvg%20xmlns%3D%22http%3A//www.w3.org/2000/svg%22%20width%3D%2212%22%20height%3D%2212%22%3E%3Cpath%20fill%3D%22%2364748b%22%20d%3D%22M6%208L1%203h10z%22/%3E%3C/svg%3E")',
    backgroundRepeat: 'no-repeat', backgroundPosition: 'right 9px center',
  },
  sortBtn: {
    display: 'flex', alignItems: 'center', gap: 4, padding: '7px 11px',
    border: `1px solid ${colors.neutralBorder}`, borderRadius: 8, fontSize: 12, background: '#fff', color: colors.textBody,
  },
  userList: { display: 'flex', flexDirection: 'column', gap: 10 },
  userCard: {
    background: '#fff', borderRadius: 12, padding: 14, border: `1px solid ${colors.border}`,
    cursor: 'pointer', transition: 'all 0.15s',
  },
  userCardSelected: { boxShadow: '0 0 0 2px rgba(24,95,165,0.15)' },
  userHeader: { display: 'flex', alignItems: 'center', gap: 12 },
  avatar: { width: 42, height: 42, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 17, fontWeight: 700, flexShrink: 0 },
  userInfo: { flex: 1, display: 'flex', flexDirection: 'column', gap: 2, minWidth: 0 },
  userName: { fontSize: 14, fontWeight: 600, color: colors.text },
  userDept: { fontSize: 12, color: colors.textMuted },
  riskBadge: { display: 'flex', alignItems: 'center', gap: 4, padding: '5px 10px', borderRadius: 6, fontSize: 13, fontWeight: 700, flexShrink: 0 },
  userDetails: { marginTop: 14, paddingTop: 14, borderTop: `1px solid ${colors.borderLight}` },
  anomaliesList: { display: 'flex', flexDirection: 'column', gap: 7 },
  anomaliesTitle: { fontSize: 11, fontWeight: 700, color: colors.textFaint, textTransform: 'uppercase', letterSpacing: '0.05em' },
  anomalyItem: { display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: colors.textBody },
  noAnomaly: { display: 'flex', alignItems: 'center', gap: 6, fontSize: 13, color: colors.success, fontWeight: 500 },
  userMeta: { marginTop: 12, display: 'flex', gap: 16, flexWrap: 'wrap' },
  metaItem: { display: 'flex', alignItems: 'center', gap: 5, fontSize: 11, color: colors.textFaint },
  analysisSection: { display: 'flex', flexDirection: 'column', gap: 14 },
  chartCard: { background: '#fff', borderRadius: 12, padding: 18, border: `1px solid ${colors.border}` },
  chartTitle: { fontSize: 14, fontWeight: 700, color: colors.text, marginBottom: 14 },
  chartContainer: { width: '100%' },
  summaryCard: { background: '#fff', borderRadius: 12, padding: 18, border: `1px solid ${colors.border}` },
  summaryContent: { display: 'flex', flexDirection: 'column', gap: 14 },
  summaryItem: { display: 'flex', flexDirection: 'column', gap: 4 },
  summaryLabel: { fontSize: 12, color: colors.textMuted },
  summaryValueRow: { display: 'flex', alignItems: 'center', gap: 8 },
  summaryValue: { fontSize: 20, fontWeight: 700, color: colors.text },
  summaryTrend: { fontSize: 11, fontWeight: 600, padding: '3px 8px', borderRadius: 5 },
  summaryValueSmall: { fontSize: 13, color: colors.text },
}
